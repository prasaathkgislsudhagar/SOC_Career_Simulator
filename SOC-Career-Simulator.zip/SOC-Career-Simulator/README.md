# 🛡️ SOC Career Simulator & Cyber Defender Progression Platform

A full-stack, gamified cybersecurity operations center (SOC) simulation platform designed for aspiring security analysts and professionals. Players start as a **Tier 1 Security Analyst** and unlock higher roles (**Tier 2 Analyst**, **Tier 3 Incident Responder**, **SOC Manager**, and **Senior SOC Manager**) by analyzing realistic SIEM alerts, triaging security incidents, mapping MITRE ATT&CK techniques, and meeting strict SLA response targets.

---

## 🚀 Key Features

- **Realistic Incident Triage**: Live SIEM log console, threat intelligence, and guided hints for incident categorization.
- **Role Progression Tree**: Unlock advanced roles based on performance scoring averages.
- **Excel Database Integration**: User profiles are stored in server-side Excel (`data/users.xlsx` under the `Users` worksheet).
- **Profile-Based Auto-Authentication**: Direct registration $\rightarrow$ Excel save $\rightarrow$ automatic authentication into the SOC simulator without separate login friction.
- **Interactive Scoring Rubric**: 7-part evaluation (Log analysis, MITRE ATT&CK alignment, containment directives, SLA compliance).
- **Audio Feedback**: Immersive cybersecurity SFX for alerts, clicks, completions, and errors.
- **Data Protection**: Direct static file downloads of database files (`data/users.xlsx`, `db/soc_platform.db`) are strictly blocked for security.

---

## 📁 Project Structure

```
.
├── index.html                  # Main application HTML shell
├── server.py                   # Python backend with openpyxl Excel integration & REST API
├── server.js                   # Node.js / Express backend option with xlsx library
├── package.json                # Node.js project manifest and dependencies
├── data/
│   └── users.xlsx              # Excel Database (Worksheet: Users)
├── db/
│   └── soc_platform.db         # SQLite storage for session tokens & progress
├── js/
│   ├── app.js                  # Application orchestrator & router
│   ├── api.js                  # HTTP REST API client
│   ├── state.js                # Central state management
│   ├── audio.js                # Web Audio API sound effects engine
│   ├── data/                   # Scenario data for Tiers 1-3, Manager & Senior Manager
│   └── views/                  # UI View controllers (Auth, Career Path, Rules, Tier workspaces)
├── css/
│   ├── main.css                # Global design system, typography & colors
│   ├── components.css          # Cards, badges, buttons, modals & toasts
│   ├── sim.css                 # SIEM terminal, triage forms & career map styles
│   └── animations.css          # Cyber scan lines, pulse glows & transitions
└── scripts/
    └── export_users.py         # Utility script to export Excel users to CSV / JSON
```

---

## 💻 Quick Start

### Option 1: Python Backend (Recommended)
```bash
# Start the server (Port 8000)
python3 server.py
```
Open **[http://localhost:8000](http://localhost:8000)** in your browser.

### Option 2: Node.js Backend
```bash
# Install dependencies
npm install

# Start the Node.js server
npm start
```
Open **[http://localhost:8000](http://localhost:8000)** in your browser.

---

## 📊 Exporting User Database
To view or export the registered user profiles from `data/users.xlsx`:
```bash
# Print formatted user table in terminal
python3 scripts/export_users.py

# Export to CSV
python3 scripts/export_users.py --csv

# Export to JSON
python3 scripts/export_users.py --json
```

---

## 📜 License
MIT License. Built for cybersecurity training, academic labs, and hands-on defender skill development.
